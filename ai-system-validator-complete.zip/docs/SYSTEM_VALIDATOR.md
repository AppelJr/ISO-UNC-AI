# AI System Validator — System Overview

Mermaid Flowchart:
```mermaid
graph TD
    A[AI System Validator<br>Threat Feed + TPM] --> B[Request Compliance Check]
    B --> C[Core Tests]
    C --> D{Extended Tests}
    C --> E[Hardware Attestation]
    E --> F[Signature Verified]
    F --> G[Recheck Threat Feeds + TPM]
    G --> A
```

This document outlines AISV’s validation flow, designed for offline and secure environments.
